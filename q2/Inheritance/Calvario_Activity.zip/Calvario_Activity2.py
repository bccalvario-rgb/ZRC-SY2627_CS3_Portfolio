#Calvario_Activity2.py
class Rectangle:
    def __init__(self, width, height):
        self.__width = width   # Private member
        self.__height = height # Private member

    # Getter for width
    @property
    def width(self):
        return self.__width

    # Setter for width
    @width.setter
    def width(self, value):
        if value > 0:
            self.__width = value
        else:
            print("Width must be greater than 0.")

    # Getter for height
    @property
    def height(self):
        return self.__height

    # Setter for height
    @height.setter
    def height(self, value):
        if value > 0:
            self.__height = value
        else:
            print("Height must be greater than 0.")


# Demonstration of usage (Working like regular variables)
if __name__ == "__main__":
    rect = Rectangle(10, 5)
    print(f"Initial Width: {rect.width}, Height: {rect.height}")
    
    # Modifying without parentheses
    rect.width = 15
    rect.height = 8
    print(f"Updated Width: {rect.width}, Height: {rect.height}")
